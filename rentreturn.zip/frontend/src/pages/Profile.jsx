import { useEffect, useState } from 'react';
import axios from '../api/axiosInstance';

export default function Profile() {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({ name: '', phone: '', address: '' });
  const [status, setStatus] = useState('');

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await axios.get('/users/me');
        setUser(res.data);
        setFormData({
          name: res.data.name || '',
          phone: res.data.phone || '',
          address: res.data.address || '',
        });
      } catch {
        setStatus('❌ Failed to load user');
      }
    };
    fetchUser();
  }, []);

  const handleChange = e => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await axios.put('/users/me', formData);
      setStatus('✅ Profile updated!');
    } catch {
      setStatus('❌ Update failed');
    }
  };

  if (!user) return <div>Loading...</div>;

  return (
    <div className="p-6 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4">👤 Edit Profile</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block">Name</label>
          <input name="name" value={formData.name} onChange={handleChange} className="w-full border p-2 rounded" />
        </div>
        <div>
          <label className="block">Phone</label>
          <input name="phone" value={formData.phone} onChange={handleChange} className="w-full border p-2 rounded" />
        </div>
        <div>
          <label className="block">Address</label>
          <input name="address" value={formData.address} onChange={handleChange} className="w-full border p-2 rounded" />
        </div>
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Save</button>
        {status && <p className="mt-2 text-sm">{status}</p>}
      </form>
    </div>
  );
}

export default function UserDashboard() {
  return <h2>User Dashboard (Coming Soon)</h2>;
}

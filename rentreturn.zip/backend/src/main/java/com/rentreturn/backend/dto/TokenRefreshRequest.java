package com.rentreturn.backend.dto;


import lombok.Data;

@Data
public class TokenRefreshRequest {

    private String refreshToken;


}

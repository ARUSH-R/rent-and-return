package com.rentreturn.backend.dto;

public class RentalCreateRequest {

    private int productId;

    private int userId;

    private String startDate;

    private String endDate;
}
